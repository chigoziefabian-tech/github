const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // settings
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (partial) => ipcRenderer.invoke('settings:set', partial),

  // music library
  listMusic: () => ipcRenderer.invoke('music:list'),
  chooseMusicFolder: () => ipcRenderer.invoke('music:choose-folder'),
  importMusicFiles: () => ipcRenderer.invoke('music:import-files'),

  // Cart Wall export (for the VOGUE SUITE Cart Wall folder)
  chooseCartWallFolder: () => ipcRenderer.invoke('cartwall:choose-folder'),
  exportToCartWall: (params) => ipcRenderer.invoke('cartwall:export', params),

  // generation pipeline
  generateScript: (params) => ipcRenderer.invoke('ai:generate-script', params), // returns an array (1-5 variations)
  generateTTS: (params) => ipcRenderer.invoke('ai:generate-tts', params),
  generateSFX: (params) => ipcRenderer.invoke('ai:generate-sfx', params),
  generateSungJingle: (params) => ipcRenderer.invoke('ai:generate-sung-jingle', params),
  mixAudio: (params) => ipcRenderer.invoke('audio:mix', params),

  // file handling
  exportFile: (params) => ipcRenderer.invoke('file:export', params),
  revealFile: (filePath) => ipcRenderer.invoke('file:reveal', filePath),

  // station profiles
  listProfiles: () => ipcRenderer.invoke('profiles:list'),
  saveProfile: (profile) => ipcRenderer.invoke('profiles:save', profile),
  deleteProfile: (name) => ipcRenderer.invoke('profiles:delete', name),

  // history
  listHistory: () => ipcRenderer.invoke('history:list'),
  addHistory: (entry) => ipcRenderer.invoke('history:add', entry),
  deleteHistory: (id) => ipcRenderer.invoke('history:delete', id),
  clearHistory: () => ipcRenderer.invoke('history:clear')
});
