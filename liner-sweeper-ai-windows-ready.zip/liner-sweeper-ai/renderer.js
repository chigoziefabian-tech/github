const el = (id) => document.getElementById(id);

const state = {
  type: 'liner',
  settings: null,
  music: [],
  profiles: [],
  history: [],
  variationScripts: [],
  lastVoicePath: null,
  lastMixPath: null
};

function setStatus(msg, kind) {
  const line = el('statusLine');
  line.textContent = msg || '';
  line.className = 'status-line' + (kind ? ` ${kind}` : '');
}

async function init() {
  state.settings = await window.api.getSettings();
  el('ttsProvider').value = state.settings.ttsProvider || 'openai';
  el('voice').value = state.settings.ttsVoice || 'alloy';
  el('sfxProvider').value = state.settings.sfxProvider || 'elevenlabs';
  el('language').value = state.settings.language || 'english';
  el('autoDuckToggle').checked = state.settings.autoDuck !== false;
  el('normalizeToggle').checked = state.settings.normalizeLoudness !== false;
  await refreshMusicList();
  await refreshProfiles();
  wireEvents();
}

async function refreshMusicList() {
  state.music = await window.api.listMusic();
  const sel = el('musicSelect');
  sel.innerHTML = '<option value="">— none —</option>';
  for (const m of state.music) {
    const opt = document.createElement('option');
    opt.value = m.path;
    opt.textContent = m.name;
    sel.appendChild(opt);
  }
}

async function refreshProfiles() {
  state.profiles = await window.api.listProfiles();
  const sel = el('profileSelect');
  sel.innerHTML = '<option value="">— station profiles —</option>';
  for (const p of state.profiles) {
    const opt = document.createElement('option');
    opt.value = p.name;
    opt.textContent = p.name;
    sel.appendChild(opt);
  }
}

function wireEvents() {
  // type segmented control
  document.querySelectorAll('#typeSeg button').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#typeSeg button').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      state.type = btn.dataset.value;
    });
  });

  el('duration').addEventListener('input', (e) => {
    el('durationVal').textContent = `${e.target.value}s`;
  });

  el('ttsProvider').addEventListener('change', () => {
    const isEleven = el('ttsProvider').value === 'elevenlabs';
    el('voiceField').style.display = isEleven ? 'none' : '';
  });

  el('genSfxBtn').addEventListener('click', async () => {
    const text = el('sfxPrompt').value.trim();
    if (!text) { setStatus('Describe the sound effect first.', 'err'); return; }
    const provider = el('sfxProvider').value;
    try {
      el('genSfxBtn').disabled = true;
      setStatus(`Generating SFX (${provider === 'stabilityai' ? 'Stable Audio' : 'ElevenLabs'})…`);
      const { path: sfxPath, name } = await window.api.generateSFX({ text, provider, kind: 'sfx' });
      await refreshMusicList();
      el('musicSelect').value = sfxPath;
      setStatus(`SFX ready: ${name}`, 'ok');
    } catch (err) {
      setStatus(err.message, 'err');
    } finally {
      el('genSfxBtn').disabled = false;
    }
  });

  el('musicDuration').addEventListener('input', (e) => {
    el('musicDurationVal').textContent = `${e.target.value}s`;
  });

  el('genMusicBtn').addEventListener('click', async () => {
    const text = el('musicPrompt').value.trim();
    if (!text) { setStatus('Describe the music/song bed first.', 'err'); return; }
    const durationSeconds = Number(el('musicDuration').value) || 30;
    try {
      el('genMusicBtn').disabled = true;
      setStatus('Generating music bed (Stable Audio)…');
      const { path: musicPath, name } = await window.api.generateSFX({
        text, provider: 'stabilityai', durationSeconds, kind: 'music'
      });
      await refreshMusicList();
      el('musicSelect').value = musicPath;
      setStatus(`Music bed ready: ${name}`, 'ok');
    } catch (err) {
      setStatus(err.message, 'err');
    } finally {
      el('genMusicBtn').disabled = false;
    }
  });

  el('genSungJingleBtn').addEventListener('click', async () => {
    const lyrics = el('jingleLyrics').value.trim();
    if (!lyrics) { setStatus('Write jingle lyrics first.', 'err'); return; }
    const style = el('jingleStyle').value.trim();
    const station = el('station').value.trim();
    try {
      el('genSungJingleBtn').disabled = true;
      setStatus('Generating sung jingle (this can take 30-120s)…');
      const { path: jinglePath, name } = await window.api.generateSungJingle({ lyrics, style, station });
      await refreshMusicList();
      el('musicSelect').value = jinglePath;
      setStatus(`Sung jingle ready: ${name} — you can also play it directly from the Music bed dropdown.`, 'ok');
    } catch (err) {
      setStatus(err.message, 'err');
    } finally {
      el('genSungJingleBtn').disabled = false;
    }
  });

  el('importFilesBtn').addEventListener('click', async () => {
    const list = await window.api.importMusicFiles();
    if (list) {
      state.music = list;
      await refreshMusicList();
      setStatus('File(s) imported into your library.', 'ok');
    }
  });

  el('chooseFolderBtn').addEventListener('click', async () => {
    const list = await window.api.chooseMusicFolder();
    if (list) {
      state.music = list;
      await refreshMusicList();
    }
  });

  el('settingsBtn').addEventListener('click', openSettings);
  el('closeSettingsBtn').addEventListener('click', closeSettings);
  el('saveSettingsBtn').addEventListener('click', saveSettings);
  el('chooseCartWallFolderBtn').addEventListener('click', async () => {
    const dir = await window.api.chooseCartWallFolder();
    if (dir) el('cartWallFolderDisplay').value = dir;
  });

  el('generateBtn').addEventListener('click', runFullPipeline);
  el('regenAudioBtn').addEventListener('click', runAudioOnly);
  el('exportBtn').addEventListener('click', exportAudio);
  el('cartWallBtn').addEventListener('click', sendToCartWall);

  // ---- Station profiles ----
  el('profileSelect').addEventListener('change', () => {
    const name = el('profileSelect').value;
    if (!name) return;
    const profile = state.profiles.find((p) => p.name === name);
    if (profile) applyProfile(profile);
  });
  el('saveProfileBtn').addEventListener('click', saveCurrentAsProfile);
  el('deleteProfileBtn').addEventListener('click', async () => {
    const name = el('profileSelect').value;
    if (!name) { setStatus('Pick a profile to delete first.', 'err'); return; }
    state.profiles = await window.api.deleteProfile(name);
    await refreshProfiles();
    setStatus(`Profile "${name}" deleted.`, 'ok');
  });

  // ---- History ----
  el('historyBtn').addEventListener('click', openHistory);
  el('closeHistoryBtn').addEventListener('click', () => { el('historyModal').hidden = true; });
  el('clearHistoryBtn').addEventListener('click', async () => {
    state.history = await window.api.clearHistory();
    renderHistory();
  });
}

// ---------------------------------------------------------------
// Station profiles — save/load the whole setup (station, tone, voice,
// providers, language) under a name so switching stations is instant.
// ---------------------------------------------------------------
function applyProfile(profile) {
  el('station').value = profile.station || '';
  el('tone').value = profile.tone || '';
  el('language').value = profile.language || 'english';
  el('textProvider').value = profile.textProvider || 'claude';
  el('ttsProvider').value = profile.ttsProvider || 'openai';
  el('ttsProvider').dispatchEvent(new Event('change'));
  if (profile.voice) el('voice').value = profile.voice;
  setStatus(`Profile "${profile.name}" applied.`, 'ok');
}

async function saveCurrentAsProfile() {
  const name = prompt('Save this setup as a profile named:');
  if (!name || !name.trim()) return;
  const profile = {
    name: name.trim(),
    station: el('station').value.trim(),
    tone: el('tone').value.trim(),
    language: el('language').value,
    textProvider: el('textProvider').value,
    ttsProvider: el('ttsProvider').value,
    voice: el('voice').value
  };
  state.profiles = await window.api.saveProfile(profile);
  await refreshProfiles();
  el('profileSelect').value = profile.name;
  setStatus(`Profile "${profile.name}" saved.`, 'ok');
}

// ---------------------------------------------------------------
// History — every script + finished audio you generate stays browsable.
// ---------------------------------------------------------------
async function openHistory() {
  state.history = await window.api.listHistory();
  renderHistory();
  el('historyModal').hidden = false;
}

function renderHistory() {
  const listEl = el('historyList');
  if (state.history.length === 0) {
    listEl.innerHTML = '<p class="hint">Nothing generated yet.</p>';
    return;
  }
  listEl.innerHTML = state.history.map((h) => `
    <div class="history-item" data-id="${h.id}">
      <div class="history-item__meta">
        <span class="badge">${h.type}</span>
        <strong>${h.station || 'Untitled'}</strong>
        <span class="hint">${new Date(h.createdAt).toLocaleString()}</span>
      </div>
      <div class="history-item__script">${(h.script || '').slice(0, 140)}${(h.script || '').length > 140 ? '…' : ''}</div>
      <div class="history-item__actions">
        <button class="btn btn--ghost btn--small" data-action="reuse">Reuse script</button>
        <button class="btn btn--ghost btn--small" data-action="play">Play</button>
        <button class="btn btn--ghost btn--small" data-action="delete">Delete</button>
      </div>
    </div>
  `).join('');

  listEl.querySelectorAll('.history-item').forEach((itemEl) => {
    const id = itemEl.dataset.id;
    const entry = state.history.find((h) => h.id === id);
    itemEl.querySelector('[data-action="reuse"]').addEventListener('click', () => {
      el('scriptOut').value = entry.script || '';
      el('regenAudioBtn').disabled = false;
      el('historyModal').hidden = true;
      setStatus('Script loaded from history — edit if needed, then Generate voice + mix.', 'ok');
    });
    itemEl.querySelector('[data-action="play"]').addEventListener('click', () => {
      if (!entry.mixPath) { setStatus('No audio saved for this entry.', 'err'); return; }
      el('audioEl').src = `file://${entry.mixPath}?t=${Date.now()}`;
      el('player').hidden = false;
      el('historyModal').hidden = true;
      el('audioEl').play();
    });
    itemEl.querySelector('[data-action="delete"]').addEventListener('click', async () => {
      state.history = await window.api.deleteHistory(id);
      renderHistory();
    });
  });
}

async function addHistoryEntry(entry) {
  state.history = await window.api.addHistory(entry);
}

function openSettings() {
  el('claudeKey').value = state.settings.apiKeys?.claude || '';
  el('openaiKey').value = state.settings.apiKeys?.openai || '';
  el('elevenKey').value = state.settings.apiKeys?.elevenlabs || '';
  el('elevenVoiceId').value = state.settings.elevenlabsVoiceId || '';
  el('stabilityKey').value = state.settings.apiKeys?.stabilityai || '';
  el('sunoKey').value = state.settings.apiKeys?.sunoapi || '';
  el('claudeModel').value = state.settings.models?.claude || 'claude-sonnet-5';
  el('openaiModel').value = state.settings.models?.openai || 'gpt-4o-mini';
  el('cartWallFolderDisplay').value = state.settings.cartWallFolder || '';
  el('settingsModal').hidden = false;
}
function closeSettings() { el('settingsModal').hidden = true; }

async function saveSettings() {
  const partial = {
    apiKeys: {
      claude: el('claudeKey').value.trim(),
      openai: el('openaiKey').value.trim(),
      elevenlabs: el('elevenKey').value.trim(),
      stabilityai: el('stabilityKey').value.trim(),
      sunoapi: el('sunoKey').value.trim()
    },
    models: {
      claude: el('claudeModel').value.trim(),
      openai: el('openaiModel').value.trim()
    },
    elevenlabsVoiceId: el('elevenVoiceId').value.trim(),
    sfxProvider: el('sfxProvider').value,
    language: el('language').value,
    autoDuck: el('autoDuckToggle').checked,
    normalizeLoudness: el('normalizeToggle').checked
  };
  state.settings = await window.api.setSettings(partial);
  closeSettings();
  setStatus('Settings saved.', 'ok');
}

function gatherScriptParams() {
  return {
    type: state.type,
    provider: el('textProvider').value,
    station: el('station').value.trim(),
    tone: el('tone').value.trim(),
    durationSec: Number(el('duration').value),
    notes: el('notes').value.trim(),
    language: el('language').value,
    variations: Number(el('variations').value) || 1
  };
}

async function runFullPipeline() {
  try {
    setStatus('Writing script…');
    el('generateBtn').disabled = true;
    const params = gatherScriptParams();
    const scripts = await window.api.generateScript(params);
    state.variationScripts = scripts;

    if (scripts.length > 1) {
      renderVariationCards(scripts);
      el('scriptOut').value = scripts[0];
    } else {
      el('variationsPanel').hidden = true;
      el('scriptOut').value = scripts[0];
    }

    el('regenAudioBtn').disabled = false;
    await runAudioOnly();
  } catch (err) {
    setStatus(err.message, 'err');
  } finally {
    el('generateBtn').disabled = false;
  }
}

function renderVariationCards(scripts) {
  const panel = el('variationsPanel');
  const container = el('variationCards');
  panel.hidden = false;
  container.innerHTML = scripts.map((s, i) => `
    <div class="variation-card ${i === 0 ? 'active' : ''}" data-idx="${i}">
      <div class="variation-card__num">Option ${i + 1}</div>
      <div class="variation-card__text">${s}</div>
    </div>
  `).join('');
  container.querySelectorAll('.variation-card').forEach((cardEl) => {
    cardEl.addEventListener('click', () => {
      container.querySelectorAll('.variation-card').forEach((c) => c.classList.remove('active'));
      cardEl.classList.add('active');
      el('scriptOut').value = state.variationScripts[Number(cardEl.dataset.idx)];
    });
  });
}

async function runAudioOnly() {
  try {
    const text = el('scriptOut').value.trim();
    if (!text) { setStatus('Write or generate a script first.', 'err'); return; }

    el('regenAudioBtn').disabled = true;
    setStatus('Recording voice…');

    // persist tts provider/voice choice
    await window.api.setSettings({
      ttsProvider: el('ttsProvider').value,
      ttsVoice: el('voice').value
    });

    const ttsProvider = el('ttsProvider').value;
    const voice = ttsProvider === 'elevenlabs'
      ? state.settings.elevenlabsVoiceId
      : el('voice').value;

    const { path: voicePath } = await window.api.generateTTS({
      provider: ttsProvider,
      text,
      voice
    });
    state.lastVoicePath = voicePath;

    setStatus('Mixing with music bed…');
    const musicPath = el('musicSelect').value || null;
    const duck = el('autoDuckToggle').checked;
    const normalize = el('normalizeToggle').checked;
    const { path: mixPath } = await window.api.mixAudio({
      voicePath,
      musicPath,
      duck,
      duckLevel: 0.22,
      tailSeconds: 1.5,
      normalize
    });
    state.lastMixPath = mixPath;

    const audioEl = el('audioEl');
    audioEl.src = `file://${mixPath}?t=${Date.now()}`;
    el('player').hidden = false;
    el('vu').classList.add('live');
    animateVU(audioEl);

    await addHistoryEntry({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      type: state.type,
      station: el('station').value.trim(),
      script: text,
      mixPath,
      createdAt: Date.now()
    });

    setStatus('Done.', 'ok');
  } catch (err) {
    setStatus(err.message, 'err');
  } finally {
    el('regenAudioBtn').disabled = false;
  }
}

function animateVU(audioEl) {
  const bars = document.querySelectorAll('#vu span');
  let timer = null;
  const tick = () => {
    bars.forEach((b) => { b.style.height = `${18 + Math.random() * 82}%`; });
  };
  audioEl.addEventListener('play', () => { timer = setInterval(tick, 110); });
  const stop = () => {
    clearInterval(timer);
    bars.forEach((b) => { b.style.height = '30%'; });
  };
  audioEl.addEventListener('pause', stop);
  audioEl.addEventListener('ended', stop);
}

async function exportAudio() {
  if (!state.lastMixPath) return;
  const station = el('station').value.trim().replace(/[^a-z0-9]+/gi, '-').toLowerCase() || 'output';
  const suggestedName = `${station}-${state.type}.mp3`;
  const saved = await window.api.exportFile({ sourcePath: state.lastMixPath, suggestedName });
  if (saved) setStatus(`Exported to ${saved}`, 'ok');
}

async function sendToCartWall() {
  if (!state.lastMixPath) return;
  const station = el('station').value.trim().replace(/[^a-z0-9]+/gi, '-').toLowerCase() || 'output';
  const suggestedName = `${station}-${state.type}-${Date.now()}.mp3`;
  try {
    const dest = await window.api.exportToCartWall({ sourcePath: state.lastMixPath, suggestedName });
    setStatus(`Sent to Cart Wall folder: ${dest}`, 'ok');
  } catch (err) {
    setStatus(err.message, 'err');
  }
}

init();
