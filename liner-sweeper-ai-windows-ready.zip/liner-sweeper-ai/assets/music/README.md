# Music beds

Drop your own royalty-free music beds / sweep FX (.mp3 or .wav) into this folder,
or use the "Folder…" button in the app to point at any folder on your machine.

These are instrumental background tracks the app ducks under the AI voice —
the app does not generate music itself.

Good free sources: Pixabay Music, Free Music Archive (check each track's license
for commercial/broadcast use before airing).
