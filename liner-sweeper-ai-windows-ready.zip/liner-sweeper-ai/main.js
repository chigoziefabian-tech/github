const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const store = require('./src/store');
const { generateScript } = require('./src/providers/textProviders');
const { generateSpeech } = require('./src/providers/ttsProviders');
const { generateSFX, generateSFXStableAudio } = require('./src/providers/sfxProvider');
const { generateSungJingle } = require('./src/providers/sungJingleProvider');
const { mixVoiceAndMusic } = require('./src/audio/mixer');

let mainWindow;

// Scratch folder for generated audio (survives for the session, cleared on quit)
const workDir = path.join(app.getPath('temp'), 'liner-sweeper-ai');
if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1180,
    height: 800,
    minWidth: 900,
    minHeight: 640,
    backgroundColor: '#0e1116',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile('index.html');
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  // clean scratch files
  try { fs.rmSync(workDir, { recursive: true, force: true }); } catch (_) {}
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// ---------- Settings (API keys, defaults) ----------
ipcMain.handle('settings:get', () => store.getAll());
ipcMain.handle('settings:set', (_evt, partial) => {
  store.setAll(partial);
  return store.getAll();
});

// ---------- Music library ----------
function listMusicFiles(dir) {
  if (!dir || !fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => /\.(mp3|wav|m4a|ogg)$/i.test(f))
    .map((f) => ({ name: f, path: path.join(dir, f) }));
}

ipcMain.handle('music:list', () => {
  const settings = store.getAll();
  const dir = settings.musicFolder || path.join(__dirname, 'assets', 'music');
  return listMusicFiles(dir);
});

ipcMain.handle('music:choose-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory']
  });
  if (result.canceled || !result.filePaths.length) return null;
  const dir = result.filePaths[0];
  store.setAll({ musicFolder: dir });
  return listMusicFiles(dir);
});

// Lets the user grab their own song / music bed / SFX file(s) straight in,
// without needing to reorganize a whole folder first.
ipcMain.handle('music:import-files', async () => {
  const settings = store.getAll();
  const dir = settings.musicFolder || path.join(__dirname, 'assets', 'music');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Audio', extensions: ['mp3', 'wav', 'm4a', 'ogg'] }]
  });
  if (result.canceled || !result.filePaths.length) return listMusicFiles(dir);

  for (const srcPath of result.filePaths) {
    const destPath = path.join(dir, path.basename(srcPath));
    fs.copyFileSync(srcPath, destPath);
  }
  return listMusicFiles(dir);
});

// ---------- Cart Wall export folder ----------
ipcMain.handle('cartwall:choose-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'] });
  if (result.canceled || !result.filePaths.length) return null;
  const dir = result.filePaths[0];
  store.setAll({ cartWallFolder: dir });
  return dir;
});

ipcMain.handle('cartwall:export', (_evt, { sourcePath, suggestedName }) => {
  const settings = store.getAll();
  if (!settings.cartWallFolder) {
    throw new Error('No Cart Wall folder set. Choose one in Settings first.');
  }
  if (!fs.existsSync(settings.cartWallFolder)) fs.mkdirSync(settings.cartWallFolder, { recursive: true });
  const destPath = path.join(settings.cartWallFolder, suggestedName || `jingle-${uuidv4().slice(0, 8)}.mp3`);
  fs.copyFileSync(sourcePath, destPath);
  return destPath;
});

// ---------- Script generation (supports batch/variations) ----------
ipcMain.handle('ai:generate-script', async (_evt, params) => {
  const settings = store.getAll();
  const provider = params.provider;
  const apiKey = settings.apiKeys?.[provider];
  if (!apiKey) {
    throw new Error(`No API key saved for ${provider}. Add one in Settings.`);
  }
  const model = settings.models?.[provider];
  const fullParams = { ...params, apiKey, model, language: params.language || settings.language };

  const count = Math.min(5, Math.max(1, Number(params.variations) || 1));
  if (count === 1) {
    const text = await generateScript(fullParams);
    return [text];
  }
  // Generate N variations in parallel so picking the best one is fast.
  const results = await Promise.allSettled(
    Array.from({ length: count }, () => generateScript(fullParams))
  );
  const scripts = results.filter((r) => r.status === 'fulfilled').map((r) => r.value);
  if (scripts.length === 0) {
    throw new Error(results[0].reason?.message || 'All script variations failed to generate.');
  }
  return scripts;
});

// ---------- TTS generation ----------
ipcMain.handle('ai:generate-tts', async (_evt, params) => {
  const settings = store.getAll();
  const provider = params.provider;
  const apiKey = settings.apiKeys?.[provider];
  if (!apiKey) {
    throw new Error(`No API key saved for ${provider}. Add one in Settings.`);
  }
  const audioBuffer = await generateSpeech({ ...params, apiKey });
  const outPath = path.join(workDir, `voice-${uuidv4()}.mp3`);
  fs.writeFileSync(outPath, audioBuffer);
  return { path: outPath };
});

// ---------- SFX / music bed generation ----------
ipcMain.handle('ai:generate-sfx', async (_evt, { text, durationSeconds, loop, provider, kind }) => {
  const settings = store.getAll();
  const itemKind = kind === 'music' ? 'music' : 'sfx';
  // ElevenLabs' sound-generation endpoint isn't built for full musical beds —
  // only Stable Audio handles the longer, musical "kind: music" requests.
  const sfxProvider = itemKind === 'music' ? 'stabilityai' : (provider || 'elevenlabs');

  let audioBuffer;
  if (sfxProvider === 'stabilityai') {
    const apiKey = settings.apiKeys?.stabilityai;
    if (!apiKey) {
      throw new Error('No Stability AI API key saved. Add one in Settings.');
    }
    audioBuffer = await generateSFXStableAudio({ apiKey, text, durationSeconds });
  } else {
    const apiKey = settings.apiKeys?.elevenlabs;
    if (!apiKey) {
      throw new Error('No ElevenLabs API key saved. Add one in Settings.');
    }
    audioBuffer = await generateSFX({ apiKey, text, durationSeconds, loop });
  }

  // Save into the active music folder so it immediately shows up as a usable bed.
  const dir = settings.musicFolder || path.join(__dirname, 'assets', 'music');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const safeName = text.trim().slice(0, 40).replace(/[^a-z0-9]+/gi, '-').toLowerCase() || itemKind;
  const fileName = `${itemKind}-${safeName}-${uuidv4().slice(0, 8)}.mp3`;
  const outPath = path.join(dir, fileName);
  fs.writeFileSync(outPath, audioBuffer);
  return { path: outPath, name: fileName };
});

// ---------- Sung jingle (Beta, third-party Suno wrapper) ----------
ipcMain.handle('ai:generate-sung-jingle', async (_evt, { lyrics, style, station }) => {
  const settings = store.getAll();
  const apiKey = settings.apiKeys?.sunoapi;
  if (!apiKey) {
    throw new Error('No Suno API (sunoapi.org) key saved. Add one in Settings — Sung Jingle section.');
  }
  const audioBuffer = await generateSungJingle({ apiKey, lyrics, style, station });

  const dir = settings.musicFolder || path.join(__dirname, 'assets', 'music');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const safeName = (station || 'jingle').trim().slice(0, 30).replace(/[^a-z0-9]+/gi, '-').toLowerCase();
  const fileName = `sung-jingle-${safeName}-${uuidv4().slice(0, 8)}.mp3`;
  const outPath = path.join(dir, fileName);
  fs.writeFileSync(outPath, audioBuffer);
  return { path: outPath, name: fileName };
});

// ---------- Mixing ----------
ipcMain.handle('audio:mix', async (_evt, { voicePath, musicPath, duck, duckLevel, tailSeconds, normalize }) => {
  const settings = store.getAll();
  const outPath = path.join(workDir, `mix-${uuidv4()}.mp3`);
  await mixVoiceAndMusic({
    voicePath,
    musicPath,
    outPath,
    duck: duck ?? settings.autoDuck ?? true,
    duckLevel: duckLevel ?? 0.22,
    tailSeconds: tailSeconds ?? 1.5,
    normalize: normalize ?? settings.normalizeLoudness ?? true
  });
  return { path: outPath };
});

// ---------- Export / file dialogs ----------
ipcMain.handle('file:export', async (_evt, { sourcePath, suggestedName }) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: suggestedName || 'liner.mp3',
    filters: [{ name: 'Audio', extensions: ['mp3'] }]
  });
  if (result.canceled || !result.filePath) return null;
  fs.copyFileSync(sourcePath, result.filePath);
  shell.showItemInFolder(result.filePath);
  return result.filePath;
});

ipcMain.handle('file:reveal', (_evt, filePath) => {
  shell.showItemInFolder(filePath);
});

// ---------- Station profiles ----------
ipcMain.handle('profiles:list', () => store.getAll().profiles || []);
ipcMain.handle('profiles:save', (_evt, profile) => {
  const existing = store.getAll().profiles || [];
  // replace if a profile with this name already exists, else add
  const withoutOld = existing.filter((p) => p.name !== profile.name);
  store.setAll({ profiles: [...withoutOld, profile] });
  return store.getAll().profiles;
});
ipcMain.handle('profiles:delete', (_evt, name) => store.deleteProfile(name));

// ---------- Generation history ----------
ipcMain.handle('history:list', () => store.getAll().history || []);
ipcMain.handle('history:add', (_evt, entry) => store.addHistory(entry));
ipcMain.handle('history:delete', (_evt, id) => store.deleteHistory(id));
ipcMain.handle('history:clear', () => store.clearHistory());
