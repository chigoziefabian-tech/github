const Store = require('electron-store');

const store = new Store({
  name: 'liner-sweeper-ai-settings',
  defaults: {
    apiKeys: {
      claude: '',
      openai: '',
      elevenlabs: '',
      stabilityai: '',
      sunoapi: ''
    },
    models: {
      claude: 'claude-sonnet-5',
      openai: 'gpt-4o-mini'
    },
    ttsProvider: 'openai',
    ttsVoice: 'alloy',
    elevenlabsVoiceId: '',
    sfxProvider: 'elevenlabs',
    musicFolder: '',
    cartWallFolder: '',
    language: 'english',
    autoDuck: true,
    normalizeLoudness: true,
    profiles: [],
    history: []
  }
});

module.exports = {
  getAll: () => store.store,
  setAll: (partial) => {
    // shallow-merge one level deep for nested objects like apiKeys/models
    const current = store.store;
    const merged = { ...current, ...partial };
    if (partial.apiKeys) merged.apiKeys = { ...current.apiKeys, ...partial.apiKeys };
    if (partial.models) merged.models = { ...current.models, ...partial.models };
    store.store = merged;
    return merged;
  },
  // ---- Station profiles (name + all the settings that define a "setup") ----
  addProfile: (profile) => {
    const current = store.store;
    const profiles = [...(current.profiles || []), profile];
    store.set('profiles', profiles);
    return profiles;
  },
  deleteProfile: (name) => {
    const current = store.store;
    const profiles = (current.profiles || []).filter((p) => p.name !== name);
    store.set('profiles', profiles);
    return profiles;
  },
  // ---- Generation history ----
  addHistory: (entry) => {
    const current = store.store;
    const history = [entry, ...(current.history || [])].slice(0, 200); // cap so the file doesn't grow forever
    store.set('history', history);
    return history;
  },
  deleteHistory: (id) => {
    const current = store.store;
    const history = (current.history || []).filter((h) => h.id !== id);
    store.set('history', history);
    return history;
  },
  clearHistory: () => {
    store.set('history', []);
    return [];
  }
};
