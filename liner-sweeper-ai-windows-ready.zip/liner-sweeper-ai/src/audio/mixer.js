const ffmpegPath = require('ffmpeg-static');
const ffmpeg = require('fluent-ffmpeg');
const ffprobeStatic = tryRequireFfprobe();

ffmpeg.setFfmpegPath(ffmpegPath);
if (ffprobeStatic) ffmpeg.setFfprobePath(ffprobeStatic);

function tryRequireFfprobe() {
  try {
    return require('ffprobe-static').path;
  } catch (_) {
    return null; // fall back to system ffprobe if not installed
  }
}

function getDuration(filePath) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => {
      if (err) return reject(err);
      resolve(data.format.duration || 0);
    });
  });
}

/**
 * Mixes a spoken-word voice track over a music bed:
 * - music plays under the voice at `duckLevel` volume (auto-ducking) — or,
 *   if `duck` is false, at a flat, un-ducked `flatMusicLevel` instead
 * - music fades in at the start and fades out `tailSeconds` after the voice ends
 * - output is trimmed to voice length + tailSeconds
 * - optionally loudness-normalized to a broadcast-friendly -16 LUFS so every
 *   liner/sweeper/jingle comes out at a consistent volume on air
 */
async function mixVoiceAndMusic({
  voicePath,
  musicPath,
  outPath,
  duck = true,
  duckLevel = 0.22,
  flatMusicLevel = 0.55,
  tailSeconds = 1.5,
  normalize = true
}) {
  const musicVolume = duck ? duckLevel : flatMusicLevel;
  const loudnormFilter = 'loudnorm=I=-16:TP=-1.5:LRA=11';

  if (!musicPath) {
    // No music bed selected — just re-encode the voice track as the final file.
    return new Promise((resolve, reject) => {
      const cmd = ffmpeg(voicePath).audioCodec('libmp3lame');
      if (normalize) cmd.audioFilters(loudnormFilter);
      cmd.on('end', () => resolve(outPath)).on('error', reject).save(outPath);
    });
  }

  const voiceDuration = await getDuration(voicePath);
  const totalDuration = voiceDuration + tailSeconds;
  const fadeOutStart = Math.max(0, totalDuration - tailSeconds);

  return new Promise((resolve, reject) => {
    const mixLabel = normalize ? '[premix]' : '[out]';
    const filters = [
      // loop/trim music to total duration, set volume (ducked or flat), fade in/out
      `[1:a]atrim=0:${totalDuration},asetpts=PTS-STARTPTS,volume=${musicVolume},` +
        `afade=t=in:st=0:d=0.6,afade=t=out:st=${fadeOutStart}:d=${tailSeconds}[music]`,
      // pad voice with silence so it matches total duration, keep full volume
      `[0:a]apad=whole_dur=${totalDuration}[voice]`,
      // mix voice + music down to stereo
      `[voice][music]amix=inputs=2:duration=first:dropout_transition=0${mixLabel}`
    ];
    if (normalize) {
      filters.push(`${mixLabel}${loudnormFilter}[out]`);
    }

    ffmpeg()
      .input(voicePath)
      .input(musicPath)
      .complexFilter(filters)
      .outputOptions(['-map', '[out]'])
      .audioCodec('libmp3lame')
      .duration(totalDuration)
      .on('end', () => resolve(outPath))
      .on('error', reject)
      .save(outPath);
  });
}

module.exports = { mixVoiceAndMusic, getDuration };
