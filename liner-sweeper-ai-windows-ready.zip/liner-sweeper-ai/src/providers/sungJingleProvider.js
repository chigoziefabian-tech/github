const fetch = require('node-fetch');

/**
 * Generates a full SUNG jingle (real melody + vocals), not just TTS reading
 * rhythmic text. Suno itself has no official public API, so this goes
 * through sunoapi.org — a documented third-party wrapper service. This is
 * clearly a different trust tier from ElevenLabs/OpenAI/Stability/Claude:
 * it's not run by Suno, so treat it as best-effort/beta.
 *
 * Flow: submit a generation job -> poll until it's done -> download the
 * finished audio.
 */
async function generateSungJingle({ apiKey, lyrics, style, station }) {
  if (!apiKey) throw new Error('Suno API (sunoapi.org) key required for sung jingles.');
  if (!lyrics || !lyrics.trim()) throw new Error('Write some jingle lyrics first.');

  const prompt = `Short radio station jingle for "${station || 'the station'}". ${style || 'upbeat, catchy, commercial jingle style'}`;

  const submitRes = await fetch('https://api.sunoapi.org/api/v1/generate', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      prompt,
      lyrics,
      instrumental: false,
      customMode: true
    })
  });
  if (!submitRes.ok) {
    const errText = await submitRes.text();
    throw new Error(`Suno API error (${submitRes.status}): ${errText}`);
  }
  const submitData = await submitRes.json();
  const jobId = submitData.id || submitData.taskId || submitData.data?.taskId;
  if (!jobId) throw new Error('Suno API did not return a job id — response shape may have changed.');

  // Poll for completion (music generation typically takes 30-120s)
  const maxAttempts = 40;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    await new Promise((r) => setTimeout(r, 4000));

    const statusRes = await fetch(`https://api.sunoapi.org/api/v1/generate/record-info?taskId=${jobId}`, {
      headers: { authorization: `Bearer ${apiKey}` }
    });
    if (!statusRes.ok) continue; // transient error, keep polling

    const statusData = await statusRes.json();
    const status = statusData.status || statusData.data?.status;
    const tracks = statusData.data?.data || statusData.tracks;

    if (status === 'complete' || status === 'success' || (tracks && tracks[0]?.audio_url)) {
      const audioUrl = tracks?.[0]?.audio_url || tracks?.[0]?.audioUrl;
      if (!audioUrl) throw new Error('Suno API marked the job complete but returned no audio URL.');
      const audioRes = await fetch(audioUrl);
      if (!audioRes.ok) throw new Error(`Could not download generated jingle audio (${audioRes.status}).`);
      const arrayBuffer = await audioRes.arrayBuffer();
      return Buffer.from(arrayBuffer);
    }
    if (status === 'failed' || status === 'error') {
      throw new Error('Suno API reported the generation failed.');
    }
    // else still processing — keep polling
  }

  throw new Error('Timed out waiting for the sung jingle to finish generating (tried for ~2.5 minutes).');
}

module.exports = { generateSungJingle };
