const fetch = require('node-fetch');
const FormData = require('form-data');

/**
 * Generates a sound effect (whoosh, stinger, ambience, etc.) from a text
 * description using ElevenLabs' text-to-SFX model. Separate from the voice
 * TTS endpoint — this returns non-speech audio.
 */
async function generateSFX({ apiKey, text, durationSeconds, loop }) {
  if (!apiKey) throw new Error('ElevenLabs API key required for SFX generation.');
  if (!text || !text.trim()) throw new Error('Describe the sound effect you want.');

  const body = {
    text,
    model_id: 'eleven_text_to_sound_v2',
    loop: !!loop
  };
  if (durationSeconds) {
    body.duration_seconds = Math.min(30, Math.max(0.5, Number(durationSeconds)));
  }

  const res = await fetch('https://api.elevenlabs.io/v1/sound-generation', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'xi-api-key': apiKey
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`ElevenLabs SFX error (${res.status}): ${errText}`);
  }

  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

/**
 * Generates a sound effect or short music bed from a text description using
 * Stability AI's Stable Audio model — a second SFX provider alongside
 * ElevenLabs, independent API key, same job (returns non-speech audio).
 */
async function generateSFXStableAudio({ apiKey, text, durationSeconds }) {
  if (!apiKey) throw new Error('Stability AI API key required for SFX generation.');
  if (!text || !text.trim()) throw new Error('Describe the sound effect you want.');

  const form = new FormData();
  form.append('prompt', text);
  form.append('output_format', 'mp3');
  form.append('model', 'stable-audio-2.5');
  if (durationSeconds) {
    form.append('duration', String(Math.min(180, Math.max(1, Number(durationSeconds)))));
  }

  const res = await fetch('https://api.stability.ai/v2beta/audio/stable-audio-2/text-to-audio', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      Accept: 'audio/*',
      ...form.getHeaders()
    },
    body: form
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Stability AI SFX error (${res.status}): ${errText}`);
  }

  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

module.exports = { generateSFX, generateSFXStableAudio };
