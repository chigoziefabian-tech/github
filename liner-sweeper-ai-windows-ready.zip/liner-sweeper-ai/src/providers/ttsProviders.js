const fetch = require('node-fetch');

async function ttsOpenAI({ apiKey, text, voice }) {
  const res = await fetch('https://api.openai.com/v1/audio/speech', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'tts-1',
      voice: voice || 'alloy',
      input: text,
      format: 'mp3'
    })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenAI TTS error (${res.status}): ${errText}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

async function ttsElevenLabs({ apiKey, text, voice }) {
  if (!voice) throw new Error('ElevenLabs voice ID is required (set it in Settings).');
  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice}`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'xi-api-key': apiKey
    },
    body: JSON.stringify({
      text,
      model_id: 'eleven_multilingual_v2',
      voice_settings: { stability: 0.45, similarity_boost: 0.8 }
    })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`ElevenLabs error (${res.status}): ${errText}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

async function generateSpeech(params) {
  switch (params.provider) {
    case 'openai':
      return ttsOpenAI(params);
    case 'elevenlabs':
      return ttsElevenLabs(params);
    default:
      throw new Error(`Unknown TTS provider: ${params.provider}`);
  }
}

module.exports = { generateSpeech };
