const fetch = require('node-fetch');

const LANGUAGE_LABELS = {
  english: 'English',
  pidgin: 'Nigerian Pidgin English',
  yoruba: 'Yoruba',
  igbo: 'Igbo',
  hausa: 'Hausa'
};

/**
 * Builds the shared instruction prompt for a liner, sweeper, or jingle.
 */
function buildPrompt({ type, station, tone, durationSec, notes, language }) {
  let kind;
  if (type === 'sweeper') {
    kind = 'sweeper (a short transitional audio ID played between songs, usually just a punchy station name + tagline, no long sentences)';
  } else if (type === 'jingle') {
    kind = 'jingle (a short, catchy, sung or chanted station ID — rhythmic, hooky, built around the station name/frequency like a mini ad-jingle, NOT plain spoken prose; write it as short rhyming/chantable lines with a clear rhythm, e.g. "Ninety-seven point seven, VOGUE FM, feel the heat!")';
  } else {
    kind = 'liner (a short DJ-style promotional read, e.g. "More music, less talk" style station imaging)';
  }

  const words = Math.max(4, Math.round((durationSec || 8) * 2.3)); // ~2.3 spoken words/sec incl. pauses
  const langLabel = LANGUAGE_LABELS[language] || 'English';
  const langLine = language && language !== 'english'
    ? `Write it in ${langLabel}. If ${langLabel} isn't your strongest language, prioritize being natural and easy to read aloud over perfect grammar — a radio producer will proofread it.`
    : 'Write it in English.';

  return `You write radio station imaging copy. Write ONE ${kind} for the station "${station || 'the station'}".
${langLine}
Tone: ${tone || 'energetic, professional'}.
Target length: about ${durationSec || 8} seconds when read aloud (roughly ${words} words). Stay close to this length.
${notes ? `Extra direction from the producer: ${notes}` : ''}

Rules:
- Output ONLY the spoken script text, nothing else (no quotes, no labels, no stage directions, no asterisks).
- No emojis, no hashtags.
- Punchy, radio-friendly rhythm, easy to read aloud.
- Do not repeat the station name more than twice.`;
}

async function generateClaude({ apiKey, model, ...params }) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: model || 'claude-sonnet-5',
      max_tokens: 300,
      messages: [{ role: 'user', content: buildPrompt(params) }]
    })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Claude API error (${res.status}): ${errText}`);
  }
  const data = await res.json();
  const text = data.content?.map((b) => b.text || '').join('').trim();
  if (!text) throw new Error('Claude returned an empty response.');
  return text;
}

async function generateOpenAI({ apiKey, model, ...params }) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: model || 'gpt-4o-mini',
      max_tokens: 300,
      messages: [{ role: 'user', content: buildPrompt(params) }]
    })
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenAI API error (${res.status}): ${errText}`);
  }
  const data = await res.json();
  const text = data.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error('OpenAI returned an empty response.');
  return text;
}

async function generateScript(params) {
  switch (params.provider) {
    case 'claude':
      return generateClaude(params);
    case 'openai':
      return generateOpenAI(params);
    default:
      throw new Error(`Unknown text provider: ${params.provider}`);
  }
}

module.exports = { generateScript, buildPrompt };
