# Liner & Sweeper AI

Desktop app (Electron) that generates radio liners and sweepers end to end:

1. **Script** — an AI (Claude or OpenAI) writes the read, timed to your target length.
2. **Voice** — an AI TTS engine (OpenAI TTS or ElevenLabs) reads it aloud.
3. **Mix** — the voice is automatically mixed over a music bed / sweep FX you supply,
   with the music ducked under the voice and faded in/out (via ffmpeg, bundled — no
   separate install needed).

## Setup

```bash
npm install
npm start
```

## API keys

Open **Settings** in the app and paste in whichever keys you have:

- **Claude** — from console.anthropic.com
- **OpenAI** — from platform.openai.com (used for script writing and/or TTS)
- **ElevenLabs** — from elevenlabs.io (optional, alternate voice engine — you'll also
  need a voice ID from your ElevenLabs voice library)

Keys are stored locally on your machine via `electron-store`, in your OS's app-data
folder. They are never sent anywhere except directly to the provider you selected.

## Music beds & SFX

Two ways to get a bed under the voice:

- **Generate one** — type a description (e.g. "bright digital whoosh sweep") in
  the SFX box and click Generate. Uses ElevenLabs' text-to-sound-effects model
  (requires an ElevenLabs API key). The result is saved into your music folder
  and auto-selected.
- **Bring your own** — put royalty-free `.mp3`/`.wav` files in `assets/music/`,
  or click **Folder…** to point at any folder. See `assets/music/README.md`.

Full multi-instrument music composition isn't generated — the SFX endpoint tops
out at 30-second clips (whooshes, stingers, ambiences, impacts), not full beds.

## How it works

- `main.js` — Electron main process; all network calls to AI providers happen here
  (not in the renderer), and it drives the ffmpeg mix.
- `src/providers/textProviders.js` — script generation (Claude / OpenAI), shared
  prompt builder that targets a spoken-word duration.
- `src/providers/ttsProviders.js` — text-to-speech (OpenAI TTS / ElevenLabs).
- `src/providers/sfxProvider.js` — sound-effect generation (ElevenLabs text-to-SFX).
- `src/audio/mixer.js` — ffmpeg pipeline: ducks the music bed, fades it, trims to the
  voice length + tail, mixes down to one MP3.
- `index.html` / `renderer.js` / `styles.css` — UI.

## Packaging a distributable

```bash
npm run dist
```

Uses `electron-builder` (config already in `package.json`) to produce an installer
for your OS in `dist/`.

## Notes

- Each generation calls the AI providers' paid APIs — usage is billed by them, not
  bundled here.
- Regenerating audio only (after you hand-edit the script) skips the script-writing
  call — use the "Generate voice + mix" button.
